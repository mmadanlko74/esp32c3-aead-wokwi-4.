#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
DEST="$ROOT/components/ascon_ref/upstream"
COMMIT="446347f21b209f3921c65ece70027c366cbe1693"

if [ -d "$DEST/.git" ]; then
  echo "Official Ascon repository already present."
else
  mkdir -p "$(dirname "$DEST")"
  git clone https://github.com/ascon/ascon-c.git "$DEST"
fi

git -C "$DEST" fetch --depth 1 origin "$COMMIT"
git -C "$DEST" checkout --detach "$COMMIT"

if [ ! -f "$DEST/crypto_aead/asconaead128/ref/api.h" ]; then
  echo "ERROR: expected official NIST SP 800-232 Ascon-AEAD128 reference api.h not found."
  exit 2
fi

echo "Pinned official Ascon source ready:"
git -C "$DEST" rev-parse HEAD
echo "Reference directory: $DEST/crypto_aead/asconaead128/ref"
