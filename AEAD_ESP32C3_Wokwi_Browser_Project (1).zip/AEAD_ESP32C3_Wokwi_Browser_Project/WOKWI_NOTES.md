# Wokwi-specific notes

- Use an ESP32-C3 board/project.
- Firmware upload is performed through the Wokwi editor command palette:
  F1 → Upload Firmware and Start Simulation.
- Serial output is the authoritative functional result for this demo.
- No INA226 is included in this Wokwi project because simulated sensor readings
  are not physical current/energy measurements. Add INA226 only in the later
  physical ESP32-C3 experiment.
- Wokwi supports uploading ESP32 `.bin`, `.elf`, or `.uf2` firmware files.
