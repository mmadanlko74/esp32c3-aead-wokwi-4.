#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_timer.h"
#include "esp_heap_caps.h"
#include "esp_random.h"
#include "mbedtls/gcm.h"
#include "mbedtls/chachapoly.h"
#include "api.h"

#define PAYLOAD_LEN 256
#define AAD_LEN 16
#define KEY_LEN 16
#define NONCE_LEN 12
#define TAG_LEN 16

static uint8_t payload[PAYLOAD_LEN];
static const uint8_t aad[AAD_LEN] = {
    'I','o','T','-','I','M','A','G','E','-','A','A','D','-','0','1'
};

/* Demonstration-only keys. Never use these fixed keys in a deployed system. */
static const uint8_t aes_key[KEY_LEN] = {
    0x10,0x21,0x32,0x43,0x54,0x65,0x76,0x87,
    0x98,0xa9,0xba,0xcb,0xdc,0xed,0xfe,0x0f
};
static const uint8_t chacha_key[32] = {
    0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,
    0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f,
    0x10,0x11,0x12,0x13,0x14,0x15,0x16,0x17,
    0x18,0x19,0x1a,0x1b,0x1c,0x1d,0x1e,0x1f
};
static const uint8_t ascon_key[16] = {
    0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,
    0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f
};

static uint8_t nonce[NONCE_LEN];
static uint8_t cipher[PAYLOAD_LEN + TAG_LEN];
static uint8_t recovered[PAYLOAD_LEN];
static uint8_t tampered[PAYLOAD_LEN + TAG_LEN];

typedef struct {
    const char *name;
    bool roundtrip;
    bool tamper_rejected;
    uint64_t enc_us;
    uint64_t dec_us;
} result_t;

static bool same_bytes(const uint8_t *a, const uint8_t *b, size_t n) {
    return memcmp(a, b, n) == 0;
}

static void make_payload(void) {
    /* Synthetic deterministic image-byte payload for functional testing only. */
    for (size_t i = 0; i < PAYLOAD_LEN; i++) {
        payload[i] = (uint8_t)((i * 37U + (i >> 2) * 13U + 19U) & 0xffU);
    }
}

static result_t test_aes_gcm(void) {
    result_t r = {"AES-128-GCM", false, false, 0, 0};
    mbedtls_gcm_context ctx;
    uint8_t tag[TAG_LEN];
    size_t out_len = 0;
    int rc;

    mbedtls_gcm_init(&ctx);
    rc = mbedtls_gcm_setkey(&ctx, MBEDTLS_CIPHER_ID_AES, aes_key, 128);
    if (rc != 0) goto done;

    int64_t t0 = esp_timer_get_time();
    rc = mbedtls_gcm_crypt_and_tag(&ctx, MBEDTLS_GCM_ENCRYPT, PAYLOAD_LEN,
            nonce, NONCE_LEN, aad, AAD_LEN, payload, cipher, TAG_LEN, tag);
    r.enc_us = (uint64_t)(esp_timer_get_time() - t0);
    if (rc != 0) goto done;
    memcpy(cipher + PAYLOAD_LEN, tag, TAG_LEN);

    t0 = esp_timer_get_time();
    rc = mbedtls_gcm_auth_decrypt(&ctx, PAYLOAD_LEN, nonce, NONCE_LEN,
            aad, AAD_LEN, cipher + PAYLOAD_LEN, TAG_LEN,
            cipher, recovered);
    r.dec_us = (uint64_t)(esp_timer_get_time() - t0);
    r.roundtrip = (rc == 0) && same_bytes(payload, recovered, PAYLOAD_LEN);

    memcpy(tampered, cipher, PAYLOAD_LEN + TAG_LEN);
    tampered[PAYLOAD_LEN + 3] ^= 0x01;
    rc = mbedtls_gcm_auth_decrypt(&ctx, PAYLOAD_LEN, nonce, NONCE_LEN,
            aad, AAD_LEN, tampered + PAYLOAD_LEN, TAG_LEN,
            tampered, recovered);
    r.tamper_rejected = (rc != 0);

done:
    mbedtls_gcm_free(&ctx);
    return r;
}

static result_t test_chachapoly(void) {
    result_t r = {"ChaCha20-Poly1305", false, false, 0, 0};
    mbedtls_chachapoly_context ctx;
    uint8_t tag[TAG_LEN];
    int rc;

    mbedtls_chachapoly_init(&ctx);
    rc = mbedtls_chachapoly_setkey(&ctx, chacha_key);
    if (rc != 0) goto done;

    int64_t t0 = esp_timer_get_time();
    rc = mbedtls_chachapoly_encrypt_and_tag(&ctx, PAYLOAD_LEN, nonce,
            aad, AAD_LEN, payload, cipher, tag);
    r.enc_us = (uint64_t)(esp_timer_get_time() - t0);
    if (rc != 0) goto done;
    memcpy(cipher + PAYLOAD_LEN, tag, TAG_LEN);

    t0 = esp_timer_get_time();
    rc = mbedtls_chachapoly_auth_decrypt(&ctx, PAYLOAD_LEN, nonce,
            aad, AAD_LEN, cipher + PAYLOAD_LEN, cipher, recovered);
    r.dec_us = (uint64_t)(esp_timer_get_time() - t0);
    r.roundtrip = (rc == 0) && same_bytes(payload, recovered, PAYLOAD_LEN);

    memcpy(tampered, cipher, PAYLOAD_LEN + TAG_LEN);
    tampered[PAYLOAD_LEN + 5] ^= 0x01;
    rc = mbedtls_chachapoly_auth_decrypt(&ctx, PAYLOAD_LEN, nonce,
            aad, AAD_LEN, tampered + PAYLOAD_LEN, tampered, recovered);
    r.tamper_rejected = (rc != 0);

done:
    mbedtls_chachapoly_free(&ctx);
    return r;
}

static result_t test_ascon(void) {
    result_t r = {"Ascon-AEAD128 (NIST SP 800-232 ref)", false, false, 0, 0};
    unsigned long long clen = 0, mlen = 0;
    int rc;

    int64_t t0 = esp_timer_get_time();
    rc = crypto_aead_encrypt(cipher, &clen, payload, PAYLOAD_LEN,
            aad, AAD_LEN, NULL, nonce, ascon_key);
    r.enc_us = (uint64_t)(esp_timer_get_time() - t0);
    if (rc != 0 || clen != PAYLOAD_LEN + TAG_LEN) return r;

    t0 = esp_timer_get_time();
    rc = crypto_aead_decrypt(recovered, &mlen, NULL, cipher, clen,
            aad, AAD_LEN, nonce, ascon_key);
    r.dec_us = (uint64_t)(esp_timer_get_time() - t0);
    r.roundtrip = (rc == 0) && (mlen == PAYLOAD_LEN) &&
                  same_bytes(payload, recovered, PAYLOAD_LEN);

    memcpy(tampered, cipher, (size_t)clen);
    tampered[PAYLOAD_LEN + 1] ^= 0x01;
    rc = crypto_aead_decrypt(recovered, &mlen, NULL, tampered, clen,
            aad, AAD_LEN, nonce, ascon_key);
    r.tamper_rejected = (rc != 0);
    return r;
}

static void print_result(const result_t *r) {
    printf("%s: round-trip=%s tamper-reject=%s enc=%llu us dec=%llu us\n",
           r->name,
           r->roundtrip ? "PASS" : "FAIL",
           r->tamper_rejected ? "PASS" : "FAIL",
           (unsigned long long)r->enc_us,
           (unsigned long long)r->dec_us);
}

void app_main(void) {
    make_payload();
    esp_fill_random(nonce, sizeof(nonce));

    printf("\n============================================\n");
    printf("AEAD ESP32-C3 functional demonstration\n");
    printf("Payload bytes: %u | AAD bytes: %u | tag bytes: %u\n",
           (unsigned)PAYLOAD_LEN, (unsigned)AAD_LEN, (unsigned)TAG_LEN);
    printf("Nonce generated at runtime (hex): ");
    for (size_t i = 0; i < NONCE_LEN; i++) printf("%02x", nonce[i]);
    printf("\n");
    printf("Note: synthetic image-byte payload; demo keys only.\n");

    result_t a = test_aes_gcm();
    result_t c = test_chachapoly();
    result_t s = test_ascon();

    print_result(&a);
    print_result(&c);
    print_result(&s);

    bool all_ok = a.roundtrip && a.tamper_rejected &&
                  c.roundtrip && c.tamper_rejected &&
                  s.roundtrip && s.tamper_rejected;

    printf("Free heap after tests: %u bytes\n",
           (unsigned)esp_get_free_heap_size());
    printf("Minimum free heap: %u bytes\n",
           (unsigned)esp_get_minimum_free_heap_size());
    printf("FINAL: %s\n", all_ok ? "ALL FUNCTIONAL CHECKS PASSED" :
                                   "ONE OR MORE CHECKS FAILED");

    while (1) vTaskDelay(pdMS_TO_TICKS(1000));
}
