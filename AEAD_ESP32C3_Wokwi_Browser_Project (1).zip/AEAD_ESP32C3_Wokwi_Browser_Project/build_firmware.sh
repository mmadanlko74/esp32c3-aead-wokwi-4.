#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

if [ -z "${IDF_PATH:-}" ] || [ ! -f "$IDF_PATH/export.sh" ]; then
  echo "ESP-IDF environment not active. Trying /opt/esp/idf/export.sh ..."
  if [ -f /opt/esp/idf/export.sh ]; then
    . /opt/esp/idf/export.sh
  else
    echo "ERROR: ESP-IDF export.sh not found in this Codespace container."
    exit 2
  fi
fi

if [ ! -f components/ascon_ref/upstream/crypto_aead/asconaead128/ref/api.h ]; then
  echo "Run ./prepare_ascon.sh first."
  exit 2
fi

idf.py set-target esp32c3
idf.py -D CMAKE_PROJECT_NAME=aead_esp32c3 build

mkdir -p build
cp build/aead_esp32c3.bin build/aead_esp32c3.bin
echo "Build completed. Firmware: $ROOT/build/aead_esp32c3.bin"
echo "ELF: $ROOT/build/aead_esp32c3.elf"
