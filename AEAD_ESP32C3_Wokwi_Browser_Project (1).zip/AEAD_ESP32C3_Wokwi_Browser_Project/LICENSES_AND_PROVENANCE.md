# Provenance and licensing notes

- Ascon source: fetched from https://github.com/ascon/ascon-c at commit
  `446347f21b209f3921c65ece70027c366cbe1693`.
- The selected source directory is `crypto_aead/asconaead128/ref`, the official
  portable reference implementation for Ascon-AEAD128 under NIST SP 800-232.
- The source repository contains its own `LICENSE` file. Review and retain that
  license when redistributing the fetched source.
- AES-GCM and ChaCha20-Poly1305 are called through the Mbed TLS component
  bundled with ESP-IDF; this project does not provide custom implementations
  of either algorithm.
- Standard reference: NIST SP 800-232, published August 2025,
  DOI: 10.6028/NIST.SP.800-232.
