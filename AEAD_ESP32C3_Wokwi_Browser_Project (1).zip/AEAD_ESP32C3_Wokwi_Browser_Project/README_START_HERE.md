# ESP32-C3 AEAD demonstration for Wokwi (browser workflow)

This project runs three authenticated-encryption implementations on an ESP32-C3 target:

1. AES-128-GCM using the ESP-IDF bundled Mbed TLS library.
2. ChaCha20-Poly1305 using the ESP-IDF bundled Mbed TLS library.
3. Ascon-AEAD128 using the **official `ascon/ascon-c` reference implementation** from the NIST SP 800-232 branch/repository.

The Ascon reference source is fetched from the official upstream repository at a pinned commit during the browser build. It is not replaced with a home-made Ascon implementation.

## Important scope and safety notes

- This is a functional firmware demonstration for Wokwi, not a physical ESP32-C3 measurement.
- Wokwi does not provide real current, voltage, or energy measurements. Do not report simulated timing, heap, or LED output as physical-device energy results.
- The firmware uses a short synthetic byte payload standing in for image bytes. It does not load a photograph from Wokwi.
- The demo generates a fresh random nonce at runtime. The hard-coded demonstration keys are not production keys. Do not deploy this firmware or reuse its keys.
- A successful round-trip and tamper rejection check demonstrate that the tested code path behaved as expected; they are not a formal security proof or certification.
- The project deliberately reports each algorithm separately. Do not treat Wokwi output as directly comparable with the Colab measurements.
- Build status: source package prepared, but it has **not** been compiled in your GitHub Codespaces account or run in your Wokwi session. The first build may expose version/toolchain issues; share the full error output if it does.

## Part 1 — Put the project in a GitHub repository (browser only)

1. Sign in at https://github.com.
2. Click **New repository**.
3. Repository name: `esp32c3-aead-wokwi`.
4. Select **Public** (needed for the simplest free workflow), then click **Create repository**.
5. On the new repository page choose **Add file → Upload files**.
6. Open this ZIP on your computer and extract it. Upload the *contents* of the extracted folder (including `.devcontainer`, `main`, `components`, `CMakeLists.txt`, and `sdkconfig.defaults`) to the repository. If GitHub's upload page does not show hidden `.devcontainer`, create that folder using **Add file → Create new file** and name it `.devcontainer/devcontainer.json`, then paste the contents from the matching file in this package.
7. Click **Commit changes**.

## Part 2 — Open the repository in Codespaces

1. In the GitHub repository, click the green **Code** button.
2. Select the **Codespaces** tab.
3. Click **Create codespace on main**.
4. Wait for the browser-based VS Code window to finish setting up. The dev-container is configured with Espressif's ESP-IDF environment.
5. Open **Terminal → New Terminal**.

## Part 3 — Fetch the official Ascon reference and build

In the Codespaces terminal, run these commands one at a time:

```bash
chmod +x prepare_ascon.sh build_firmware.sh
./prepare_ascon.sh
./build_firmware.sh
```

The first script clones the official `ascon/ascon-c` repository at commit
`446347f21b209f3921c65ece70027c366cbe1693` and exposes only
`crypto_aead/asconaead128/ref` to this firmware build.

The second script builds for `esp32c3`. On success, the application binary is:

```text
build/aead_esp32c3.bin
```

The ELF file is:

```text
build/aead_esp32c3.elf
```

If the `idf.py` command is not found, first run:

```bash
. $IDF_PATH/export.sh
```

Then retry `./build_firmware.sh`.

## Part 4 — Start Wokwi with the compiled firmware

1. Open https://wokwi.com/projects/new/esp32-c3 in another browser tab.
2. In the Wokwi code editor press **F1**.
3. Select **Upload Firmware and Start Simulation…**.
4. In the Codespaces file explorer, download `build/aead_esp32c3.bin` to your computer (right-click the file → Download).
5. Select that downloaded `.bin` file in the Wokwi upload dialog.
6. Open the Serial Monitor. The firmware prints a result for each algorithm. The Serial Monitor reports PASS/FAIL for each check.

If the template URL changes, start a new ESP32-C3 project from Wokwi's project gallery and use its custom-firmware upload command.

## Expected serial output pattern

The measured microsecond values will vary by simulator and build. The output should have this general form:

```text
AEAD ESP32-C3 functional demonstration
Payload bytes: 256
AES-128-GCM: round-trip=PASS tamper-reject=PASS ...
ChaCha20-Poly1305: round-trip=PASS tamper-reject=PASS ...
Ascon-AEAD128 (NIST SP 800-232 ref): round-trip=PASS tamper-reject=PASS ...
FINAL: ALL FUNCTIONAL CHECKS PASSED
```

Do not copy expected example values into your paper. Record only values actually produced by your own run and label them as simulated.

## If anything fails

Copy the complete terminal build error or Wokwi Serial Monitor output and send it back. Do not change the Ascon source files or replace Ascon-AEAD128 with an older Ascon-128a implementation.
